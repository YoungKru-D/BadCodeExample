#ifndef __TEXTURE_H__
#define __TEXTURE_H__

#include "texture.cpp"

#endif
