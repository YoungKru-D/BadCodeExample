#ifndef __SPARKS_H__
#define __SPARKS_H__

#include "sparks.cpp"

#endif
