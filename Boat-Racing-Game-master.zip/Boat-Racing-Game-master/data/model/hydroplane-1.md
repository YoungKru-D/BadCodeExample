## Reference images of the real hydroplane:

From http://www.h1unlimited.com/

* ![Top View](http://www.h1unlimited.com/wp-content/uploads/2016/02/Hmestreet1.jpg)
* ![Side View](http://www.h1unlimited.com/wp-content/uploads/2016/02/Homestreet2.jpg)
* ![Side View](http://www.h1unlimited.com/wp-content/uploads/2016/06/June-10th-Testing-007.jpg)
* ![Front View](http://www.h1unlimited.com/wp-content/uploads/2016/06/June-10th-Testing-086.jpg)

From http://www.boatdesign.net/forums/hydrodynamics-aerodynamics/catamarans-high-speed-blow-over-causes-solutions-48276-3.html
* ![Top and Side View](http://www.socalbeachesblog.com/wp-content/uploads/2010/09/san_diego_powerboat-races-2.jpg)
