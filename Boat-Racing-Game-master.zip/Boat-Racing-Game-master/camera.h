#ifndef __CAMERA_H__
#define __CAMERA_H__

#include "camera.cpp"

#endif
