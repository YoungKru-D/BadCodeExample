#ifndef __ANIMATION_H__
#define __ANIMATION_H__

#include "animation.cpp"

#endif
