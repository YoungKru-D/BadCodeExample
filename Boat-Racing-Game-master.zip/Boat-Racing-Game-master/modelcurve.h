#ifndef __MODELCURVE_H__
#define __MODELCURVE_H__

#include "modelcurve.cpp"

#endif
