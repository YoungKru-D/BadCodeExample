#ifndef __SKY_H__
#define __SKY_H__

#include "sky.cpp"

#endif
