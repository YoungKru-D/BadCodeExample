#ifndef __MODEL_H__
#define __MODEL_H__

#include "model.cpp"

#endif
