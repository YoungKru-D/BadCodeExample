#ifndef __SHADER_H__
#define __SHADER_H__

#include "shader.cpp"

#endif
