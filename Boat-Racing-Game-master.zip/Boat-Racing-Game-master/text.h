#ifndef __TEXT_H__
#define __TEXT_H__

#include "text.cpp"

#endif
