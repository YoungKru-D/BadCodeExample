#ifndef __BOAT_H__
#define __BOAT_H__

#include "boat.cpp"

#endif
