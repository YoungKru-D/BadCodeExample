#ifndef __SOUNDCLOUD_H__
#define __SOUNDCLOUD_H__

#include "soundcloud.cpp"

#endif
