#ifndef __PLATFORM_H__
#define __PLATFORM_H__

#include "platform.cpp"

#endif
