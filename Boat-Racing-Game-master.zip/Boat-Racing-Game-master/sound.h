#ifndef __SOUND_H__
#define __SOUND_H__

#include "sound.cpp"

#endif
