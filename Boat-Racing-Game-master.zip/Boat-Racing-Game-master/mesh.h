#ifndef __MESH_H__
#define __MESH_H__

#include "mesh.cpp"

#endif
